import { Hono } from 'hono'
import { zValidator } from '@hono/zod-validator'
import { z } from 'zod'
import type { Bindings, Variables } from '../types'
import { authMiddleware } from '../middleware/auth'
import { ok, fail, paginate, parsePagination } from '../middleware/response'

const groups = new Hono<{ Bindings: Bindings; Variables: Variables }>()

// ── 그룹 목록 (공개) ──────────────────────────────────
groups.get('/', async (c) => {
  const { page, limit, offset } = parsePagination(c.req.query('page'), c.req.query('limit'))
  const search = c.req.query('q')
  const category = c.req.query('category')

  let query = `
    SELECT g.*, u.name as admin_name,
      (SELECT COUNT(*) FROM group_members WHERE group_id = g.id AND status = 'active') as member_count
    FROM groups g
    LEFT JOIN users u ON u.id = g.admin_user_id
    WHERE g.status = 'active' AND g.is_deleted = 0 AND g.visibility = 'public'
  `
  const params: unknown[] = []
  if (search) { query += ` AND (g.name LIKE ? OR g.description LIKE ?)`; params.push(`%${search}%`, `%${search}%`) }
  if (category) { query += ` AND g.category = ?`; params.push(category) }
  query += ` ORDER BY g.is_featured DESC, g.created_at DESC LIMIT ? OFFSET ?`
  params.push(limit, offset)

  const [rows, countRow] = await Promise.all([
    c.env.DB.prepare(query).bind(...params).all(),
    c.env.DB.prepare(`SELECT COUNT(*) as total FROM groups WHERE status='active' AND is_deleted=0 AND visibility='public'`).first<{ total: number }>()
  ])

  return c.json(paginate(rows.results, countRow?.total ?? 0, page, limit))
})

// ── 그룹 개설 신청 ────────────────────────────────────
groups.post(
  '/',
  authMiddleware,
  zValidator('json', z.object({
    name: z.string().min(2).max(100),
    description: z.string().max(1000).optional(),
    category: z.enum(['association', 'company', 'club', 'other']).default('other'),
    visibility: z.enum(['public', 'private']).default('public'),
    custom_join_fields: z.string().optional()  // JSON 문자열
  })),
  async (c) => {
    const userId = c.get('userId')
    const body = c.req.valid('json')

    const result = await c.env.DB.prepare(`
      INSERT INTO groups (name, description, category, visibility, status, admin_user_id, custom_join_fields)
      VALUES (?, ?, ?, ?, 'pending', ?, ?)
    `).bind(body.name, body.description ?? null, body.category, body.visibility, userId, body.custom_join_fields ?? null).run()

    return c.json(ok({
      group_id: result.meta.last_row_id,
      status: 'pending',
      message: '그룹 개설 신청이 완료되었습니다. 슈퍼관리자 승인 후 활성화됩니다.'
    }), 201)
  }
)

// ── 그룹 상세 조회 ────────────────────────────────────
groups.get('/:id', async (c) => {
  const groupId = c.req.param('id')

  const group = await c.env.DB.prepare(`
    SELECT g.*, u.name as admin_name,
      (SELECT COUNT(*) FROM group_members WHERE group_id = g.id AND status = 'active') as member_count
    FROM groups g
    LEFT JOIN users u ON u.id = g.admin_user_id
    WHERE g.id = ? AND g.is_deleted = 0
  `).bind(groupId).first()

  if (!group) return c.json(fail('그룹을 찾을 수 없습니다.'), 404)

  const photos = await c.env.DB.prepare(
    'SELECT * FROM group_photos WHERE group_id = ? ORDER BY sort_order LIMIT 10'
  ).bind(groupId).all()

  return c.json(ok({ ...group, photos: photos.results }))
})

// ── 그룹 가입 신청 ────────────────────────────────────
groups.post('/:id/join', authMiddleware, async (c) => {
  const userId = c.get('userId')
  const groupId = parseInt(c.req.param('id'))
  const body = await c.req.json().catch(() => ({}))

  const group = await c.env.DB.prepare(
    `SELECT id, visibility, status, max_members FROM groups WHERE id = ? AND is_deleted = 0`
  ).bind(groupId).first<{ id: number; visibility: string; status: string; max_members: number | null }>()

  if (!group || group.status !== 'active') {
    return c.json(fail('그룹을 찾을 수 없거나 활성 상태가 아닙니다.'), 404)
  }

  // 이미 가입 여부 확인
  const existing = await c.env.DB.prepare(
    'SELECT status FROM group_members WHERE group_id = ? AND user_id = ?'
  ).bind(groupId, userId).first<{ status: string }>()

  if (existing) {
    if (existing.status === 'active') return c.json(fail('이미 가입된 그룹입니다.'), 409)
    if (existing.status === 'pending') return c.json(fail('이미 가입 신청 중입니다.'), 409)
  }

  // 최대 멤버 수 확인
  if (group.max_members) {
    const memberCount = await c.env.DB.prepare(
      `SELECT COUNT(*) as cnt FROM group_members WHERE group_id = ? AND status = 'active'`
    ).bind(groupId).first<{ cnt: number }>()
    if ((memberCount?.cnt ?? 0) >= group.max_members) {
      return c.json(fail('그룹 정원이 가득 찼습니다.'), 409)
    }
  }

  const status = group.visibility === 'public' ? 'pending' : 'pending'

  await c.env.DB.prepare(`
    INSERT OR REPLACE INTO group_members (group_id, user_id, status, join_fields)
    VALUES (?, ?, ?, ?)
  `).bind(groupId, userId, status, JSON.stringify(body.join_fields ?? {})).run()

  return c.json(ok({
    group_id: groupId,
    status,
    message: '가입 신청이 완료되었습니다. 관리자 승인을 기다려주세요.'
  }), 201)
})

// ── 그룹 탈퇴 ────────────────────────────────────────
groups.delete('/:id/leave', authMiddleware, async (c) => {
  const userId = c.get('userId')
  const groupId = parseInt(c.req.param('id'))

  const member = await c.env.DB.prepare(
    `SELECT role FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'`
  ).bind(groupId, userId).first<{ role: string }>()

  if (!member) return c.json(fail('그룹 멤버가 아닙니다.'), 404)
  if (member.role === 'admin') return c.json(fail('관리자는 직접 탈퇴할 수 없습니다. 권한 이임 후 탈퇴해주세요.'), 400)

  await c.env.DB.prepare(`
    UPDATE group_members SET status = 'left', left_at = datetime('now'), updated_at = datetime('now')
    WHERE group_id = ? AND user_id = ?
  `).bind(groupId, userId).run()

  // 그룹 명함 비활성화
  await c.env.DB.prepare(
    `UPDATE cards SET is_active = 0, updated_at = datetime('now') WHERE group_id = ? AND user_id = ? AND card_type = 'group'`
  ).bind(groupId, userId).run()

  return c.json(ok(null, '그룹에서 탈퇴했습니다.'))
})

// ── 그룹 멤버 목록 (관리자용) ────────────────────────
groups.get('/:id/members', authMiddleware, async (c) => {
  const userId = c.get('userId')
  const groupId = parseInt(c.req.param('id'))
  const { page, limit, offset } = parsePagination(c.req.query('page'), c.req.query('limit'))
  const status = c.req.query('status') ?? 'active'

  // 관리자 여부 확인
  const member = await c.env.DB.prepare(
    `SELECT role FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'`
  ).bind(groupId, userId).first<{ role: string }>()

  if (!member || !['admin', 'sub_admin'].includes(member.role)) {
    return c.json(fail('그룹 관리자만 멤버 목록을 조회할 수 있습니다.'), 403)
  }

  const [rows, countRow] = await Promise.all([
    c.env.DB.prepare(`
      SELECT gm.*, u.name, u.email, u.avatar_url, u.account_type
      FROM group_members gm
      JOIN users u ON u.id = gm.user_id
      WHERE gm.group_id = ? AND gm.status = ?
      ORDER BY gm.joined_at DESC
      LIMIT ? OFFSET ?
    `).bind(groupId, status, limit, offset).all(),
    c.env.DB.prepare(
      'SELECT COUNT(*) as total FROM group_members WHERE group_id = ? AND status = ?'
    ).bind(groupId, status).first<{ total: number }>()
  ])

  return c.json(paginate(rows.results, countRow?.total ?? 0, page, limit))
})

// ── 멤버 승인/거절 (관리자) ───────────────────────────
groups.patch(
  '/:id/members/:userId',
  authMiddleware,
  zValidator('json', z.object({
    action: z.enum(['approve', 'reject', 'kick']),
    role: z.string().optional()
  })),
  async (c) => {
    const adminId = c.get('userId')
    const groupId = parseInt(c.req.param('id'))
    const targetUserId = parseInt(c.req.param('userId'))
    const { action, role } = c.req.valid('json')

    // 관리자 권한 확인
    const adminMember = await c.env.DB.prepare(
      `SELECT role FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'`
    ).bind(groupId, adminId).first<{ role: string }>()

    if (!adminMember || !['admin', 'sub_admin'].includes(adminMember.role)) {
      return c.json(fail('권한이 없습니다.'), 403)
    }

    const statusMap = { approve: 'active', reject: 'rejected', kick: 'kicked' }
    const newStatus = statusMap[action]

    await c.env.DB.prepare(`
      UPDATE group_members
      SET status = ?,
          ${action === 'approve' ? 'joined_at = datetime(\'now\'), approved_by = ' + adminId + ',' : ''}
          ${action !== 'approve' && action === 'kick' ? 'left_at = datetime(\'now\'),' : ''}
          ${role ? 'role = \'' + role + '\',' : ''}
          updated_at = datetime('now')
      WHERE group_id = ? AND user_id = ?
    `).bind(newStatus, groupId, targetUserId).run()

    const messages = { approve: '승인', reject: '거절', kick: '강제 탈퇴' }
    return c.json(ok(null, `멤버를 ${messages[action]}했습니다.`))
  }
)

// ── 공지사항 목록 ────────────────────────────────────
groups.get('/:id/notices', async (c) => {
  const groupId = c.req.param('id')
  const { page, limit, offset } = parsePagination(c.req.query('page'), c.req.query('limit'))

  const [rows, countRow] = await Promise.all([
    c.env.DB.prepare(`
      SELECT n.*, u.name as author_name
      FROM notices n
      JOIN users u ON u.id = n.author_id
      WHERE n.group_id = ? AND n.is_deleted = 0
      ORDER BY n.is_pinned DESC, n.created_at DESC
      LIMIT ? OFFSET ?
    `).bind(groupId, limit, offset).all(),
    c.env.DB.prepare(
      'SELECT COUNT(*) as total FROM notices WHERE group_id = ? AND is_deleted = 0'
    ).bind(groupId).first<{ total: number }>()
  ])

  return c.json(paginate(rows.results, countRow?.total ?? 0, page, limit))
})

// ── 공지사항 작성 (관리자) ───────────────────────────
groups.post(
  '/:id/notices',
  authMiddleware,
  zValidator('json', z.object({
    title: z.string().min(1).max(200),
    content: z.string().min(1),
    is_pinned: z.number().int().min(0).max(1).default(0)
  })),
  async (c) => {
    const userId = c.get('userId')
    const groupId = parseInt(c.req.param('id'))
    const body = c.req.valid('json')

    const member = await c.env.DB.prepare(
      `SELECT role FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'`
    ).bind(groupId, userId).first<{ role: string }>()

    if (!member || !['admin', 'sub_admin', 'executive'].includes(member.role)) {
      return c.json(fail('공지사항 작성 권한이 없습니다.'), 403)
    }

    const result = await c.env.DB.prepare(`
      INSERT INTO notices (group_id, author_id, title, content, is_pinned)
      VALUES (?, ?, ?, ?, ?)
    `).bind(groupId, userId, body.title, body.content, body.is_pinned).run()

    return c.json(ok({ notice_id: result.meta.last_row_id }, '공지사항이 등록되었습니다.'), 201)
  }
)

// ── 관리자 권한 이임 요청 ────────────────────────────
groups.post(
  '/:id/transfer-admin',
  authMiddleware,
  zValidator('json', z.object({
    to_user_id: z.number().int().positive()
  })),
  async (c) => {
    const userId = c.get('userId')
    const groupId = parseInt(c.req.param('id'))
    const { to_user_id } = c.req.valid('json')

    // 현재 관리자 확인
    const group = await c.env.DB.prepare(
      `SELECT admin_user_id FROM groups WHERE id = ? AND is_deleted = 0`
    ).bind(groupId).first<{ admin_user_id: number }>()

    if (!group || group.admin_user_id !== userId) {
      return c.json(fail('그룹 관리자만 권한을 이임할 수 있습니다.'), 403)
    }

    // 대상 유저가 그룹 멤버인지 확인
    const targetMember = await c.env.DB.prepare(
      `SELECT id FROM group_members WHERE group_id = ? AND user_id = ? AND status = 'active'`
    ).bind(groupId, to_user_id).first()

    if (!targetMember) {
      return c.json(fail('대상 유저가 그룹 멤버가 아닙니다.'), 400)
    }

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()

    await c.env.DB.prepare(`
      INSERT INTO group_admin_transfers (group_id, from_user_id, to_user_id, status, expires_at)
      VALUES (?, ?, ?, 'pending', ?)
    `).bind(groupId, userId, to_user_id, expiresAt).run()

    return c.json(ok(null, '관리자 권한 이임 요청을 발송했습니다. 대상자의 수락을 기다려주세요.'), 201)
  }
)

export default groups
